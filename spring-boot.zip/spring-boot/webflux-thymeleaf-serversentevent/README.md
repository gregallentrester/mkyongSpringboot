# Spring Boot WebFlux + Server-sent events example

Article link : https://www.mkyong.com/spring-boot/spring-boot-webflux-server-sent-events-example/

## 1. How to start
```
$ mvn spring-boot:run
```

Access http://localhost:8080
